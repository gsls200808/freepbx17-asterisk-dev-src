/*
 * buildopts.h
 * Automatically generated
 */

#define OPTIONAL_API 1
#define AST_BUILDOPT_SUM "da6642af068ee5e6490c5b1d2cc1d238"
#define AST_BUILDOPTS "OPTIONAL_API"
#define AST_BUILDOPTS_ALL "BUILD_NATIVE, OPTIONAL_API"
