/*
 * build.h
 * Automatically generated
 */
#define BUILD_HOSTNAME "freepbx17"
#define BUILD_KERNEL "6.1.0-27-amd64"
#define BUILD_MACHINE "x86_64"
#define BUILD_OS "Linux"
#define BUILD_DATE "2026-01-25 01:42:06 UTC"
#define BUILD_USER "root"

